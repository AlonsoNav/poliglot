#Reto 3 ----------------------------------------------------
import pickle
import random
def lee(): 
    try:
        f = open("juntaDirectiva.dat", "rb")
        dicc = pickle.load(f)
        f.close
        return dicc
    except:
        print("No se encontró el archivo: juntaDirectiva.dat, se iniciará el programa sin datos previos.")
        return []
    
def grabar(pList): 
    f =  open("juntaDirectiva.dat","wb")
    pickle.dump(pList,f)
    f.close()
    return

class Puesto:
    def __init__(self):
        self.rol = 0
        self.nombre = ""
        self.procedencia = False
        self.idioma = []
    def getRol(self):
        return self.rol
    def getNombre(self):
        return self.nombre
    def getProcedencia(self):
        return self.procedencia
    def getIdioma(self):
        return self.idioma
    def setRol(self, rol):
        self.rol = rol
    def setNombre(self, nombre):
        self.nombre = nombre
    def setProcedencia(self, procedencia):
        self.procedencia = procedencia
    def setIdioma(self, idioma):
        self.idioma = idioma
    def mostrarTodo(self):
        return (self.rol, self.nombre, self.procedencia, self.idioma)

def insertarPuesto(lista):
    procedencias = [True, False]
    for e in range(1,9):
        idiomas = []
        miembro = Puesto()
        miembro.setRol(e)
        miembro.setNombre(f"nombre{e} apellido{e}")
        miembro.setProcedencia(random.choice(procedencias))
        for k in range(3):
            while True:
                idioma = random.randint(1,10)
                if idioma not in idiomas:
                    idiomas.append(idioma)
                    break
        miembro.setIdioma(idiomas)
        lista.append(miembro)
    grabar(lista)
    return "Datos agregados exitósamente."

def modificarIdiomaMenu1():
    roles = {1: "Presidente", 2: "Vicepresidente", 3:"Tesorero(a)", 4:"Secretario(a)", 5: "Vocal 1", 6: "Vocal 2", 7: "Vocal 3", 8:"Fiscal"}
    for e in roles:
        print(e, roles[e])
    opcion = int(input("Ingrese el número del rol que desea modificar: "))
    return modificarIdiomaMenu2(opcion, listaObjetos)

def modificarIdiomaMenu2(opcion, lista):
    idiomas = {1:"Español", 2: "Inglés", 3:"Alemán", 4: "Francés", 5:"Portugués", 6:"Chino", 7: "Mandarín", 8: "Coreano", 9:"Árabe", 10:"Hindi"}
    for e in lista:
        if e.getRol() == opcion:
            datos = e.mostrarTodo()
            persona = e
    print()
    print(f"Rol a cargo de: {datos[1]}")
    print("Actualmente habla: \n")
    for e in datos[3]:
        print(idiomas[e])
    return modificarIdiomaMenu3(idiomas, persona)

def modificarIdiomaMenu3(idiomas, persona):
    while True:
        print("\n\nSeleccion el idioma que desea registrar: ")
        for e in idiomas:
            print(f"{e})    {idiomas[e]}")
        idioma = int(input("\n:: "))
        if int(idioma) not in persona.getIdioma():
            print(f"Se va a modificar el idioma {idiomas[persona.getIdioma()[2]]} por {idiomas[idioma]}")
            print("1) Continuar             2) Cancelar")
            confirmacion = input(":: ")
            if confirmacion == "1":
                persona.setIdioma([persona.getIdioma()[0],persona.getIdioma()[1], idioma])
                grabar(listaObjetos)
                return "Idioma modificado exitosamente."
            else:
                return "Idioma no modificado."
        else: print("La persona ya tiene ese idioma registrado")

def eliminarPuesto(lista):
    roles = {1: "Presidente", 2: "Vicepresidente", 3:"Tesorer(a)", 4:"Secretario(a)", 5: "Vocal 1", 6: "Vocal 2", 7: "Vocal 3", 8:"Fiscal"}
    for e in roles:
        print(e, roles[e])
    opcion = int(input("Ingrese número del rol que desea eliminar: "))
    print(f"Se va a eliminar el puesto de {roles[opcion]}")
    print("1) Continuar             2) Cancelar")
    confirmacion = input(":: ")
    if confirmacion == "1":
        for e in lista:
            if e.getRol() == opcion:
                lista.pop(lista.index(e))
        grabar(listaObjetos)
        return "Idioma modificado exitosamente."
    else:
        return "Idioma no modificado."

def mostrarInfoCompleta(lista):
    roles = {1: "Presidente", 2: "Vicepresidente", 3:"Tesorero(a)", 4:"Secretario(a)", 5: "Vocal 1", 6: "Vocal 2", 7: "Vocal 3", 8:"Fiscal"}
    idiomas = {1:"Español", 2: "Inglés", 3:"Alemán", 4: "Francés", 5:"Portugués", 6:"Chino", 7: "Mandarín", 8: "Coreano", 9:"Árabe", 10:"Hindi"}
    print("\nLos miembros de la junta directiva son: ")
    for e in lista:
        datos = e.mostrarTodo()
        print()
        print(f"---- {roles[datos[0]]} ----")
        print(datos[1])
        if datos[2]:
            print("Procedente de un colegio público.")
        else: print("Procedente de un colegio privado.")
        print("Habla: \n")
        for k in datos[3]:
            print(idiomas[k])
    return ""
            

