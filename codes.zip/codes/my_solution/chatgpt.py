import pickle
import random


class Puesto:
    IDIOMAS = {
        1: "Español", 2: "Inglés", 3: "Alemán", 4: "Francés",
        5: "Portugués", 6: "Chino", 7: "Mandarín", 8: "Coreano",
        9: "Árabe", 10: "Hindi"
    }

    def __init__(self, rol=0, nombre="", procedencia=False, idiomas=None):
        self.rol = rol
        self.nombre = nombre
        self.procedencia = procedencia
        self.idiomas = idiomas or (0, 0, 0)

    # Métodos get
    def get_rol(self):
        return self.rol

    def get_nombre(self):
        return self.nombre

    def get_procedencia(self):
        return self.procedencia

    def get_idiomas(self):
        return self.idiomas

    # Métodos set
    def set_rol(self, rol):
        self.rol = rol

    def set_nombre(self, nombre):
        self.nombre = nombre

    def set_procedencia(self, procedencia):
        self.procedencia = procedencia

    def set_idiomas(self, idiomas):
        self.idiomas = idiomas

    # Mostrar información
    def mostrar(self):
        procedencia_text = "Público" if self.procedencia else "Privado"
        idiomas_text = ", ".join(Puesto.IDIOMAS[i] for i in self.idiomas)
        return f"Rol: {self.rol}, Nombre: {self.nombre}, Procedencia: {procedencia_text}, Idiomas: {idiomas_text}"


def cargar_datos():
    try:
        with open("jd_data.pkl", "rb") as file:
            return pickle.load(file)
    except FileNotFoundError:
        return []


def guardar_datos(jd):
    with open("jd_data.pkl", "wb") as file:
        pickle.dump(jd, file)


def insertar_puestos(jd):
    roles = [
        "Presidente", "Vicepresidente", "Tesorero(a)", "Secretario(a)",
        "Vocal 1", "Vocal 2", "Vocal 3", "Fiscal"
    ]
    nombres_base = [
        "Juan Pérez", "María Gómez", "Carlos Sánchez", "Ana López",
        "Luis Ramírez", "Sofía Torres", "Miguel Díaz", "Laura Castillo"
    ]

    for i, rol in enumerate(roles, start=1):
        nombre = nombres_base[i - 1]
        procedencia = random.choice([True, False])
        idiomas = tuple(random.sample(range(1, 11), 3))
        jd.append(Puesto(rol=i, nombre=nombre, procedencia=procedencia, idiomas=idiomas))

    guardar_datos(jd)


def modificar_idioma(jd):
    print("\nSeleccione un puesto para modificar su idioma:")
    for i, puesto in enumerate(jd, start=1):
        print(f"{i}. {puesto.get_nombre()}")

    try:
        indice = int(input("\nIngrese el número del puesto: ")) - 1
        if indice < 0 or indice >= len(jd):
            print("Opción inválida. Intente de nuevo.")
            return

        puesto = jd[indice]

        print(f"\nIdiomas actuales de {puesto.get_nombre()}:")
        for i, idioma in enumerate(puesto.get_idiomas(), start=1):
            print(f"{i}. {Puesto.IDIOMAS[idioma]}")

        nuevo_idioma = 0
        while (
            nuevo_idioma in puesto.get_idiomas()
            or nuevo_idioma == 0
            or nuevo_idioma not in Puesto.IDIOMAS
        ):
            print("\nSeleccione un nuevo idioma que no sea uno de los actuales:")
            for key, value in Puesto.IDIOMAS.items():
                print(f"{key}. {value}")
            try:
                nuevo_idioma = int(input("\nIngrese el número del idioma: "))
                if nuevo_idioma not in Puesto.IDIOMAS:
                    print("Idioma inválido. Intente nuevamente.")
            except ValueError:
                print("Entrada no válida. Intente de nuevo.")

        # Actualizar idiomas
        idiomas_actualizados = puesto.get_idiomas()[:2] + (nuevo_idioma,)
        puesto.set_idiomas(idiomas_actualizados)

        print(f"\nIdiomas actualizados para {puesto.get_nombre()}:")
        for i, idioma in enumerate(idiomas_actualizados, start=1):
            print(f"{i}. {Puesto.IDIOMAS[idioma]}")

        guardar_datos(jd)
        print("\nIdioma modificado exitosamente.")

    except ValueError:
        print("Entrada no válida. Intente de nuevo.")



def eliminar_puesto(jd):
    print("\nSeleccione un puesto para eliminar:")
    for i, puesto in enumerate(jd, start=1):
        print(f"{i}. {puesto.get_nombre()}")

    indice = int(input("\nIngrese el número del puesto a eliminar: ")) - 1
    jd.pop(indice)
    guardar_datos(jd)


def mostrar_roles(jd):
    print("\nInformación completa de los roles activos:")
    for puesto in jd:
        print(puesto.mostrar())


def main():
    jd = cargar_datos()

    if not jd:
        print("\nNo hay datos cargados. Se insertarán nuevos puestos automáticamente.")
        insertar_puestos(jd)

    while True:
        print("\nMenú de opciones:")
        print("1. Modificar idioma")
        print("2. Eliminar un puesto")
        print("3. Mostrar información completa")
        print("4. Salir")
        opcion = int(input("\nSeleccione una opción: "))

        if opcion == 1:
            modificar_idioma(jd)
        elif opcion == 2:
            eliminar_puesto(jd)
        elif opcion == 3:
            mostrar_roles(jd)
        elif opcion == 4:
            print("\nGracias por usar el sistema. ¡Hasta luego!")
            break
        else:
            print("\nOpción inválida. Intente de nuevo.")


if __name__ == "__main__":
    main()
