import pickle
import random

roles = {
    1: "Presidente", 
    2: "Vicepresidente", 
    3: "Tesorero(a)",
    4: "Secretario(a)", 
    5: "Vocal 1", 
    6: "Vocal 2", 
    7: "Vocal 3",
    8: "Fiscal"
}

idiomas = {
    1: "Español", 
    2: "Inglés", 
    3: "Alemán", 
    4: "Francés", 
    5: "Portugués", 
    6: "Chino", 
    7: "Mandarín", 
    8: "Coreano", 
    9: "Árabe", 
    10: "Hindi"
}

junta_directiva = []

"""
Clase Puesto
Atributos:
- nombre: str
- rol: int
- idioma: tuple
- procedencia: bool
"""
class Puesto:
    def __init__(self, nombre = "", rol = 0, idioma = (), procedencia = False):
        self.rol = rol
        self.nombre = nombre
        self.idioma = idioma
        self.procedencia = procedencia

    def getRol(self):
        return self.rol

    def getNombre(self):
        return self.nombre

    def getIdioma(self):
        return self.idioma

    def getProcedencia(self):
        return self.procedencia

    def setRol(self, rol):
        self.rol = rol

    def setNombre(self, nombre):
        self.nombre = nombre

    def setIdioma(self, idioma): 
        self.idioma = idioma

    def setProcedencia(self, procedencia):
        self.procedencia = procedencia
    
    def __str__(self):
        return (f"Nombre: {self.nombre}\n"
                f"\tRol: {roles[self.rol]}\n"
                f"\tIdiomas: {", ".join([idiomas[i] for i in self.idioma])}\n"
                f"\tProcedencia: {"Colegio público" if self.procedencia else "Colegio privado"}")


def cargar_junta_directiva():
    global junta_directiva
    try:
        with open("junta_directiva.txt", "rb") as file:
            junta_directiva = pickle.load(file)
    except FileNotFoundError:
        pass


def guardar_junta_directiva():
    with open("junta_directiva.txt", "wb") as file:
        pickle.dump(junta_directiva, file)


def confirmar_accion(mensaje): 
    return input(mensaje + " (s/n): ").lower() == "s"


def mostrar_junta_directiva():
    for i, puesto in enumerate(junta_directiva):
        print(f"{i + 1}. {puesto}")



# Obtiene una entrada numérica y maneja el error si la entrada no es un número.
def obtener_entrada(mensaje):
    entrada = input(mensaje)
    return int(entrada) if entrada.isdigit() else 0


def menu_puestos():
    mostrar_junta_directiva()
    puesto = obtener_entrada("Seleccione un puesto a modificar: ") - 1
    if puesto < 0 or puesto >= len(junta_directiva):
        print("Puesto inválido")
        return None
    return puesto



# Inserta 8 puestos aleatorios en la junta directiva con su respectivo nombre, rol, idiomas y procedencia.
def insertar_puesto():
    if len(junta_directiva) == 8 and not confirmar_accion("La junta directiva ya tiene 8 puestos, ¿desea sobreescribirla?"):
        return
    junta_directiva.clear()
    for rol in roles:
        junta_directiva.append(Puesto(f"Nombre{rol}", rol, tuple(random.sample(range(1, 11), 3)), random.choice([True, False])))
    guardar_junta_directiva()
    


# Modifica el idioma de un puesto en la junta directiva.
def modificar_idioma():
    puesto = menu_puestos()
    if puesto is None:
        return
    print("Idiomas: ")
    for idioma, nombre in idiomas.items():
        print(f"{idioma}. {nombre}")
    idioma = obtener_entrada("Seleccione un idioma: ")
    if idioma < 1 or idioma > 10:
        print("Idioma inválido")
        return
    if idioma in junta_directiva[puesto].idioma:
        print("El idioma ya está en la lista")
        return
    junta_directiva[puesto].setIdioma(junta_directiva[puesto].getIdioma()[:-1] + (idioma,))
    guardar_junta_directiva()



# Elimina un puesto de la junta directiva.
def eliminar_puesto():
    puesto = menu_puestos()
    if puesto is None:
        return
    if confirmar_accion("¿Está seguro de eliminar el puesto?"):
        junta_directiva.pop(puesto)
        guardar_junta_directiva()


def main():
    cargar_junta_directiva()

    opciones = {
        1: insertar_puesto,
        2: modificar_idioma,
        3: eliminar_puesto,
        4: mostrar_junta_directiva,
        5: lambda: print("Saliendo del programa...")
    }

    opcion = 0
    while opcion != 5:
        print("--- Junta Directiva ---")
        print("Menú")
        print("1. Insertar puesto")
        print("2. Modificar idioma")
        print("3. Eliminar puesto")
        print("4. Mostrar junta directiva")
        print("5. Salir")
        opcion = obtener_entrada("Seleccione una opción: ")
        opciones.get(opcion, lambda: print("Opción inválida"))()


if __name__ == "__main__":
    main()